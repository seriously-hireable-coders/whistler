// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAWoRCn1udT83j1f1aHuOGzBPPNaVg1k98",
  authDomain: "whistler-b627a.firebaseapp.com",
  projectId: "whistler-b627a",
  storageBucket: "whistler-b627a.appspot.com",
  messagingSenderId: "702938089827",
  appId: "1:702938089827:web:4b71afe6ca1603ed77eb56"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app;
